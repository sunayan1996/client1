# -*- coding: utf-8 -*-
from django.http import HttpResponse
import requests
from django.shortcuts import render
import json
def farm(request):
	r = requests.get('http://127.0.0.1:8000/farms/farmpoints')
	a = requests.get('http://127.0.0.1:8000/farms/farmlist')
	a=a.json()
	j = r.json()
	farm_id=[]
	farm_ids=[]
	house_id=[]
	area = []
	lat=[[]]
	lon=[[]]
	l1=[]
	l2=[]
	q=1
	for k in j:
		if q==1:
			farm_id.append(k['farm_id'])
			l1.append(float(k['lat']))
			l2.append(float(k['lon']))
			q=2
		else:
			if k['farm_id'] in farm_id:
				l1.append(float(k['lat']))
				l2.append(float(k['lon']))
			else:
				lat.append(l1)
				lon.append(l2)
				farm_id.append(k['farm_id'])
				l1=[]
				l2=[]
				l1.append(float(k['lat']))
				l2.append(float(k['lon']))
	lat.append(l1)
	lon.append(l2)
	lat.remove([])
	lon.remove([])
	for h in a:
		farm_ids.append(h['id'])
		house_id.append(h['house_id'])
		area.append(float(h['area']))
	print farm_ids
	print area
	print house_id
	h_id=[]
	for c in farm_id:
		ind=farm_ids.index(c)
		h_id.append(house_id[ind])
	print h_id
	context={'lat':lat,'lon':lon,'farm_id':farm_id,'area':area,'h_id':h_id}		
	return render(request, 'maps/farm.html', context)




def house(request):
	r=requests.get('http://127.0.0.1:8000/farms/houselist')
	a=requests.get('http://127.0.0.1:8000/farms/members')
	j=r.json()
	a=a.json()
	house_id=[]
	lat=[]
	lon=[]
	mi=[]
	for k in j:
		house_id.append(k['id'])
		lat.append(float(k['lat']))
		lon.append(float(k['lon']))
		mi.append(k['mon_income'])

	person_names={}
	person_dob={}
	for k in a:
		if k['house_id'] in person_names:
			person_names[k['house_id']].append(str(k['name']))
		else:
			person_names[k['house_id']]=[str(k['name'])]
	for k in a:
		if k['house_id'] in person_dob:
			person_dob[k['house_id']].append(str(k['DOB']))
		else:
			person_dob[k['house_id']]=[str(k['DOB'])]
	
	#print person_names[4][0]
	#print person_dob
	#print house_id
	#print mi
	info=[]
	st=''
	for s in house_id:
		m=person_names[s]
		n=person_dob[s]
		for v in range(len(m)):
			st=st+str(m[v])+' DOB : '+n[v]+'\n'
		info.append(st)
		st=''
		#print house_id
		print info[0]
	context={'lat':lat,'lon':lon,'house_id':house_id,'mi':mi,'info':info}
	return render(request, 'maps/house.html', context)









def well(request):
	r = requests.get('http://127.0.0.1:8000/farms/farmpoints')
	a=requests.get('http://127.0.0.1:8000/farms/welllist')
	a=a.json()
	j = r.json()
	farm_id=[]
	lat=[[]]
	lon=[[]]
	l1=[]
	l2=[]
	lat1=[]
	lon1=[]
	depth=[]
	well_id=[]
	avg_yield=[]
	q=1
	f_id=[]
	for k in j:
		if q==1:
			farm_id.append(k['farm_id'])
			l1.append(float(k['lat']))
			l2.append(float(k['lon']))
			q=2
		else:
			if k['farm_id'] in farm_id:
				l1.append(float(k['lat']))
				l2.append(float(k['lon']))
			else:
				lat.append(l1)
				lon.append(l2)
				farm_id.append(k['farm_id'])
				l1=[]
				l2=[]
				l1.append(float(k['lat']))
				l2.append(float(k['lon']))
	lat.append(l1)
	lon.append(l2)
	lat.remove([])
	lon.remove([])
	for k in a:
		f_id.append(k['farm_id'])
		well_id.append(k['id'])
		lat1.append(float(k['lat']))
		lon1.append(float(k['lon']))
		depth.append(float(k['depth_in_meters']))
		avg_yield.append(float(k['Avg_wateryield']))
	farmid=sorted(farm_id)
	context={'lat':lat,'lon':lon,'farm_id':farm_id,'f_id':f_id,'lat1':lat1,'lon1':lon1,'depth':depth,'avg_yield':avg_yield,'well_id':well_id}		
	return render(request, 'maps/well.html', context)







