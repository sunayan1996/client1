from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^maps/farm/$', views.farm),
	url(r'^maps/house/$', views.house),
	url(r'^maps/well/$', views.well),
]
